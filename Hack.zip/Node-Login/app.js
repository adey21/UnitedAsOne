
var http = require('http');
var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var errorHandler = require('errorhandler');
var cookieParser = require('cookie-parser');
var MongoStore = require('connect-mongo')(session);
var app = express();

app.locals.pretty = true;
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/app/server/views');
app.set('view engine', 'jade');
app.use(cookieParser());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(require('stylus').middleware({ src: __dirname + '/app/public' }));
app.use(express.static(__dirname + '/app/public'));

// build mongo database connection url //

var dbHost = process.env.DB_HOST || 'localhost'
var dbPort = process.env.DB_PORT || 27017;
var dbName = process.env.DB_NAME || 'node-login';

var dbURL = 'mongodb://'+dbHost+':'+dbPort+'/'+dbName;
if (app.get('env') == 'live'){
// prepend url with authentication credentials // 
	dbURL = 'mongodb://'+process.env.DB_USER+':'+process.env.DB_PASS+'@'+dbHost+':'+dbPort+'/'+dbName;
}

app.use(session({
	secret: 'faeb4453e5d14fe6f6d04637f78077c76c73d1b4',
	proxy: true,
	resave: true,
	saveUninitialized: true,
	store: new MongoStore({ url: dbURL })
	})
);

var count = 0;
var isAnswered = false;
var questionInitials = [
	"Are you interested in filling out a short survey to enhance our product and services?",
    "What do you think about our products and services?",
	"Do you recommend Subs gift-box to your friend or colleague?",
	"Do you provide us suggestions to improve our product and services?",
	"Provide your comments about our product and services?",
	"Provide your suggestions to improve our product and services?"
];

var count = 0;
var filloutCount = 0;
var port = 3000;
var io = require('socket.io').listen(app.listen(port));
var sentiment = require('sentiment');
io.sockets.on('connection', function(socket) {
	
    var myDate = new Date();
    if (myDate.getHours() < 12) {
        socket.emit('message', {
            message: 'Good Morning!, Welcome to the webgility survey!!'
        });
    } else
    if (myDate.getHours() >= 12 && myDate.getHours() <= 17) {
        socket.emit('message', {
            message: 'Good Afternoon!, Welcome to the webgility survey!!'
        });
    } else
    if (myDate.getHours() > 17 && myDate.getHours() <= 24) {
        socket.emit('message', {
            message: 'Good Evening!, Welcome to the webgility survey!!'
        });
    } else {
        console.log("I'm not sure what time it is!");
    }

    console.log("goining inside:");
    setInterval(() => {
        if (filloutCount == 0) {
            socket.emit('message', {
                message: questionInitials[0]
            });
            filloutCount++;
        }
    }, 3500);


    socket.on('send', function(data) {
        io.sockets.emit('message', data);
		
		var r1 = sentiment(data.message);
		
		io.sockets.emit ('messageSuccess', r1);
 
		if (data.message.toLowerCase().search(/no/i) != -1) {
		io.sockets.emit('message', {message:'Thank u, see u later!!'});
		}
		if (data.message.toLowerCase().search(/what is your name/i) != -1) {
		io.sockets.emit('message', {message:'I am WG BOT. What is yours'});
		}
		if (data.message.toLowerCase().search(/hi/i) != -1) {
		io.sockets.emit('message', {message:'Hello '+data.username});
		}
		else
		{
		 setInterval(() => {
        //console.log("goining inside:", isAnswered, count);
        if (isAnswered && count <= 2) {
            socket.emit('message', {
                message: questionInitials[count]
            });

            count++;
            isAnswered = false;
        }
    }, 3500);		   
        console.log("RKO: ", data);
			
		}
    });
	
});
console.log("Listening on port " + port);

require('./app/server/routes')(app);



