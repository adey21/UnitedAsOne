
$(document).ready(function() {
	 var logindata=[5, 10, 15, 20, 25, 30];
	 var question1=[12, 19, 3, 5, 2, 3];
	 var question2=[12, 19, 3, 5, 2, 3];
	loginChart(logindata);
	surveyQuestion1Chart(question1);
	surveyQuestion2Chart(question2);
	surveyQuestion3Chart(question1);
	surveyQuestion4Chart(question1);
	surveyQuestion5Chart(question1);
	   
});

function loginChart(data1)
{
	
var ctx = document.getElementById("myChart");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Customer's"],
        datasets: [{
            label: '# of Customers',
            data: data1,
            backgroundColor: [
			'rgba(153, 102, 255, 0.2)'
            ],
            borderColor: [
			'rgba(153, 102, 255, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
}

function surveyQuestion1Chart(data1)
{
	
	var ctx = document.getElementById("mySurveyresponse1");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Negative", "Positive", "Can't Say"],
        datasets: [{
            label: '# of Customers',
            data: data1,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
}

function surveyQuestion2Chart(data1)
{
	
	var ctx = document.getElementById("mySurveyresponse2");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Negative", "Positive", "Can't Say"],
        datasets: [{
            label: '# of Customers',
            data: data1,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
}

function surveyQuestion3Chart(data1)
{
	
	var ctx = document.getElementById("mySurveyresponse3");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Negative", "Positive", "Can't Say"],
        datasets: [{
            label: '# of Customers',
            data: data1,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
}

function surveyQuestion4Chart(data1)
{
	
	var ctx = document.getElementById("mySurveyresponse4");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Negative", "Positive", "Can't Say"],
        datasets: [{
            label: '# of Customers',
            data: data1,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
}

function surveyQuestion5Chart(data1)
{
	
	var ctx = document.getElementById("mySurveyresponse5");
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Negative", "Positive", "Can't Say"],
        datasets: [{
            label: '# of Customers',
            data: data1,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
}