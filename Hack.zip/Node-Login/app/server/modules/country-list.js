
module.exports = [
    {short:"  " , name:"Please select a country"},
    {short:"IN" , name:"India"},
    {short:"NZ" , name:"New Zealand"},
    {short:"SG" , name:"Singapore"},
    {short:"SZ" , name:"Swaziland"},
    {short:"GB" , name:"United Kingdom"},
    {short:"US" , name:"United States"}
    ]